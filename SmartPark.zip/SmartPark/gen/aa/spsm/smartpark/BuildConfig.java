/** Automatically generated file. DO NOT MODIFY */
package aa.spsm.smartpark;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}